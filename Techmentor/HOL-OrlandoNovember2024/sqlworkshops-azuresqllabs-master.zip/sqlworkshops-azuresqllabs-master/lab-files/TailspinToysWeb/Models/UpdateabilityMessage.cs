﻿namespace TailspinToysWeb.Models
{
    public class UpdateabilityMessage
    {
        public string Message { get; set; }
    }
}